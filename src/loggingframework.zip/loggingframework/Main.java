package loggingframework;

import loggingframework.entities.LogManager;
import loggingframework.entities.Logger;
import loggingframework.enums.LogLevel;
import loggingframework.strategies.ConsoleAppender;
import loggingframework.strategies.FileAppender;

import java.util.Map;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Logger rootLogger = LogManager.getInstance().getRootLogger();
        rootLogger.addAppender(new ConsoleAppender());
        rootLogger.addAppender(new FileAppender("C:/Users/pupul/OneDrive/Desktop/LLD/lld_practice/src/loggingframework/logging.txt"));
        Logger logger = LogManager.getInstance().getLogger("com.oracle.component");
        logger.debug("Debugging :)");
        Thread.sleep(1000);
    }
}
